import os, json, configparser

from functions import func
from datetime import datetime, timedelta

abs_path = os.path.abspath(__file__).rpartition('/')[0]
f_api = f'{abs_path}/data/settings/api_config.ini'
fd_session = f'{abs_path}/sessions'

# api_id = 3525120
# api_hash = 'c1a57a09f86fe1ae55ed3f3d1238bf55'
# phone_number = '+380953864385'
all_iris = [707693258, 5226378684, 5137994780, 5434504334, 5443619563]
black_iris = '5443619563'
ub_admin = [6417262719]

f_config = f'{abs_path}/data/settings/user_config.ini'
trusted_f = f'{abs_path}/data/settings/trusted.json'
victims_file = f'{abs_path}/data/settings/victims.json'
victims_file_dump = f'{abs_path}/data/settings/victims_dump.json'
victims_exclusion = f'{abs_path}/data/settings/victims_exclusion.json'
my_illnesses_file = f'{abs_path}/data/settings/my_illnesses.json'
js_info = f'{abs_path}/data/settings/user_info.json'
user_config_js = f'{abs_path}/data/settings/user_config.json'
f_chats_config = f'{abs_path}/data/settings/chats_configs.json'
js_detective_storage = f'/home/night/TG-usebots/bio-detective_real/storage/chat_data.json'

# настройки
class Settings:
    def __init__(self, cf):
        read = configparser.ConfigParser()
        read.read(cf)
        read = read['user_settings']
        with open(f_chats_config, 'r', encoding='utf-8') as fr:
            chatsc_js_read = json.load(fr)
        
        self.name = read['name'].lower()
        self.name_en = func.ru2en(self.name).lower()
        self.prefix = read['prefix']
        self.prefix_en = func.ru2en(self.prefix)
        self.sex = read['sex']
        self.autoanswer_time = read['autoanswer_time']
        self.autoanswer_everytime = int(read['autoanswer_everytime'])
        self.autoanswer_num = 1
        self.autoanswer_random = func.str2bool(read['autoanswer_random'])
        self.autoanswer_chats = chatsc_js_read
        self.autoanswer_chat = read['autoanswer_chat']
        self.dov_limited = func.str2bool(read['dov_limited'])
        self.call_api = func.str2bool(read['call_api'])
        self.autoheal = func.str2bool(read['autoheal'])
        self.autoheal_full = func.str2bool(read['autoheal_full'])
        self.autoheal_parted = int(read['autoheal_parted'])
        self.autoheal_random = func.str2bool(read['autoheal_random'])
        self.autoheal_num = 1
        self.infect_thanks = func.str2bool(read['infect_thanks'])
        self.infect_reaction = func.str2bool(read['infect_reaction'])
        self.auto_ex = (False if read['auto_ex'] == 'False' else read['auto_ex'])
        self.vampir = func.str2bool(read['vampir'])
        self.auto_infecter_sync = func.str2bool(read['auto_infecter_sync'])
        self.auto_infecter_percent = int(read['auto_infecter_percent'])
        self.auto_infecter_time = read['auto_infecter_time']
        self.auto_infecter_chat_sync = int(read['auto_infecter_chat_sync'])
        self.auto_infecter_chat = read['auto_infecter_chat']
        self.where_mode = read['where_mode']
        self.list_infect_delay = float(read['list_infect_delay'])
        self.visual_victims = func.str2bool(read['visual_victims'])
        self.zar_backuper = None
        self.lab_get = False
        self.trusted = func.json_read(trusted_f)
    def refresh(self, cf):
        read = configparser.ConfigParser()
        read.read(cf)
        read = read['user_settings']
        with open(f_chats_config, 'r', encoding='utf-8') as fr:
            chatsc_js_read = json.load(fr)
        
        self.name = read['name'].lower()
        self.name_en = func.ru2en(self.name).lower()
        self.prefix = read['prefix']
        self.prefix_en = func.ru2en(self.prefix)
        self.sex = read['sex']
        self.autoanswer_time = read['autoanswer_time']
        self.autoanswer_everytime = int(read['autoanswer_everytime'])
        self.autoanswer_num = self.autoanswer_num
        self.autoanswer_random = func.str2bool(read['autoanswer_random'])
        self.autoanswer_chats = chatsc_js_read
        self.autoanswer_chat = read['autoanswer_chat']
        self.dov_limited = func.str2bool(read['dov_limited'])
        self.call_api = func.str2bool(read['call_api'])
        self.autoheal = func.str2bool(read['autoheal'])
        self.autoheal_full = func.str2bool(read['autoheal_full'])
        self.autoheal_parted = int(read['autoheal_parted'])
        self.autoheal_random = func.str2bool(read['autoheal_random'])
        self.autoheal_num = 1
        self.infect_thanks = func.str2bool(read['infect_thanks'])
        self.infect_reaction = func.str2bool(read['infect_reaction'])
        self.auto_ex = (False if read['auto_ex'] == 'False' else read['auto_ex'])
        self.vampir = func.str2bool(read['vampir'])
        self.auto_infecter_sync = func.str2bool(read['auto_infecter_sync'])
        self.auto_infecter_percent = int(read['auto_infecter_percent'])
        self.auto_infecter_time = read['auto_infecter_time']
        self.auto_infecter_chat_sync = int(read['auto_infecter_chat_sync'])
        self.auto_infecter_chat = read['auto_infecter_chat']
        self.where_mode = read['where_mode']
        self.list_infect_delay = float(read['list_infect_delay'])
        self.visual_victims = func.str2bool(read['visual_victims'])
        self.zar_backuper = None
        self.lab_get = False
        self.trusted = func.json_read(trusted_f)
    def correct(self):
        if self.autoanswer_everytime == 0:
            self.autoanswer_num = 0
        if self.autoheal_parted == 0:
            self.autoheal_num = 0


class MeInfo:
    def __init__(self):
        with open(js_info, 'r', encoding='utf-8') as fw:
            read = json.load(fw)
        
        self.pathogen_name = read['pathogen_name']
        self.ready_pathogens = read['ready_pathogens']
        self.scientist_qualification = read['scientist_qualification']
        
        self.infectivity = read['infectivity']
        self.immunity = read['immunity']
        self.lethality = read['lethality']
        self.security_service = read['security_service']
        
        self.bio_resources = read['bio-resources']
        
        self.victims_food = read['victims_food']
        
        if read['lethality']:
            z_date = datetime.today() + timedelta(days=int(read['lethality']))
            self.zar_date = z_date.strftime("%d.%m.%Y")
        else:
            self.zar_date = None
    def refresh(self):
        with open(js_info, 'r', encoding='utf-8') as fw:
            read = json.load(fw)
        
        self.pathogen_name = read['pathogen_name']
        self.ready_pathogens = read['ready_pathogens']
        self.scientist_qualification = read['scientist_qualification']
        
        self.infectivity = read['infectivity']
        self.immunity = read['immunity']
        self.lethality = read['lethality']
        self.security_service = read['security_service']
        
        self.bio_resources = read['bio-resources']
        
        self.victims_food = read['victims_food']
        
        if read['lethality']:
            z_date = datetime.today() + timedelta(days=int(read['lethality']))
            self.zar_date = z_date.strftime("%d.%m.%Y")
        else:
            self.zar_date = None

class Me:
    me = {}


class GlobalStack:
    stop = False
    list_zar = False
    auto_zar = False

class Zapominalka:
    heal_previous_msg = None
    heal_pause = False

class MyIllnesses:
    def __init__(self):
        read = func.json_read(my_illnesses_file)
        self.illnesses = read
    def refresh(self):
        read = func.json_read(my_illnesses_file)
        self.illnesses = read


class CycleTimers:
    def __init__(self):
        self.read = func.json_read(user_config_js)
        self.timer_1 = self.read['cycle_timers']['timer_1']
        self.timer_2 = self.read['cycle_timers']['timer_2']
        self.timer_3 = self.read['cycle_timers']['timer_3']
        self.timer_4 = self.read['cycle_timers']['timer_4']
        self.timer_5 = self.read['cycle_timers']['timer_5']
        self.timer_6 = self.read['cycle_timers']['timer_6']
        self.timer_7 = self.read['cycle_timers']['timer_7']
        self.timer_8 = self.read['cycle_timers']['timer_8']
        self.all_timers = [self.timer_1, self.timer_2, self.timer_3, self.timer_4, self.timer_5, self.timer_6, self.timer_7, self.timer_8]
    def refresh(self):
        self.read = func.json_read(user_config_js)
        self.timer_1 = self.read['cycle_timers']['timer_1']
        self.timer_2 = self.read['cycle_timers']['timer_2']
        self.timer_3 = self.read['cycle_timers']['timer_3']
        self.timer_4 = self.read['cycle_timers']['timer_4']
        self.timer_5 = self.read['cycle_timers']['timer_5']
        self.timer_6 = self.read['cycle_timers']['timer_6']
        self.timer_7 = self.read['cycle_timers']['timer_7']
        self.timer_8 = self.read['cycle_timers']['timer_8']
        self.all_timers = [self.timer_1, self.timer_2, self.timer_3, self.timer_4, self.timer_5, self.timer_6, self.timer_7, self.timer_8]


class JsRead():
    def __init__(self):
        try:
            self.count = 0
            self.js_read = func.json_read(victims_file)
        except json.decoder.JSONDecodeError:
            os.replace(victims_file_dump, victims_file)
    def reload(self, refresh=False):
        if self.count > 16 or refresh:
            self.count = 0
            self.js_read = func.json_read(victims_file)
        else:
            self.count += 1

class VictimsEclusionRead:
    def __init__(self):
        with open(victims_exclusion, 'r', encoding='utf-8') as f:
            read = json.load(f)
        self.js_read = read
    def refresh(self):
        with open(victims_exclusion, 'r', encoding='utf-8') as f:
            read = json.load(f)
        self.js_read = read


where_triggers_cute = [
    '.мхмхх~~сладкий..! А-АХХ..!! м.. ч-чуть нежнее~!.. ахх!!. мгмх!.. ахх~я~я больше не мог-уу!мхмх... быстрее~^^я..... аххх.. ~ХМХХмхмм...~АААХ Е! ~я не могу... не останавливайся!\nмхм..ахххх..накажи к-как следует с-своего.. ААААХ~~аххьяяя.. афф.. слишком... а-ааах чуть нежнее..!!!... а~ахх~мфъфмхмхфх.. ~быстрей... ахмф...быстреей!! ~ахмм...\nмх~мнг~мгм.. имфф~быстреей!ах..глубже... ахх.. ~ещё.... аххх~ глубже-е... мхфмхфммм.. а-а!! мфф...остановись~!! ьбьбь.. ахх ААХХХХ аххмм..очень..аххмфхм..~мхаххх мфмфффммм...~ мгм.. н не так... ахх~ сильно... АХХХ мххфмх.. ахххмхамхфмх.. аа...АААХ~..мгнмн~ нет.. пх хватит ммммм.. как глубоко... аххх.. ААХХХХ.. накажи.. мфм.. не останавливайся..!! сладкий.. ~мрмрмфф.. ААХХ..',
    'выебать', 'Ваш покорный слуга здесь!', 'Звездочка ✨', 'Самый хороший раб, это - послушный раб',
    'Я здесь и жду ваших указаний сэр', 'Я буду находится рядом, только чтобы делать тебя счастливым',
    "Don't fear, i will never miss you again 💓", 'Have me all', 'Я в твоему служении',
    'здесЯ', 'трахнуть', 'Не мешай мне пожалуйста 😖', 'я занята сейчас, извини', 'м?',
    'Погладить', 'обнять', 'отдаться', 'поцеловать', 'Я сплю 😴',
    'Я всегда рядом, чтобы любить и заботиться о тебе', 'Здравствуйте', 'Только дай повод, и я выполню все твои желанные мысли',
    'А ты случаем не местный дурачек?', 'Ave Ronnita',
    'Я куплю твои воспоминания, только назови цену 🤭', 'обнять', 'Дав-а-а-й полетаем... с тоб-о-о-й',
    'Твоя улыбка светит ярче самого солнца и делает этот мир прекраснее',
    'С тобой я чувствую себя более особеннее', 'Твоя прекрасная душа искрится ярче самых красивых звезд на небе',
    'Я здесь, соскучилась?', 'Приветик', 'Шлю свой сладкий поцелуй тебе', 'Я в твоей власти мой Повелитель',
    'Ты приснишься мне во снах и надеюсь, я приснюсь тебе тоже',
    'Мои сны только о тебе', 'я так люблю гулять по ночам.... ты романтик? я маньяк',
    'горя в аду я вспоминаю твою улыбку', 'растопи мое сердце солнышко', 'Сучка в красном, выглядишь прекрасно))',
    'подари мне первый танец, забери меня с собой...',
    'я буду руки твои целовать, я стану грустью в улыбке твоей и нам никто не посмеет мешать и не отнимет у нас этих дней',
    'В сердце твоем была не я, в сердце твоем была одна, но ты об этом промолчал, со мной любовь сыграл...',
    'У меня в постели', 'я вот смотрю на твои фотки, скольких женщин ты свел с ума своей улыбкой и натурой?',
    'сон дал мне возможность обнять тебя', 'ай ю мэссидж, бэйби'
    
    
    
]

where_triggers_evil = [
    'раз-два-три-четыре-пять вышел зайчик погулять, вдруг охотник выбегает - прямо в зайчика стреляет! Пиф! Паф! Ой-ой-ой умирает зайчик мой... принесли его домой оказался он живой',
    'у тебя маленький 😳', 'Куда скачешь чмошник?', 'Чуєш, ти гiмно мале', 'Ти блять дурний як цап',
    'ты жалок', 'Отвали', 'Отьебись', 'убить', '🏳️‍🌈', 'Ишак ебаный, хули приебался ко мне?',
    'Двести двадвцять восьмая диванная механизированная бригада под пивасом не месте, Сэр!',
    'Отьебись нахуй псина', 'Сьебался нахуй', 'только дай детям игрушку...',
    'Ja pierdolę kurwa co chcesz?', 'твою маму любил', 'засосать', 'Парашник ебучий',
    'уебать', 'ты гей', 'пидорас', 'ты пидор', 'а хуй тебе', 'бaн', 'Нахуя ты меня триггеришь блядота?',
    'Я ору! Ну ты окунь', 'Ну я, что хотел?', 'зарaзить', 'Буу!', 'Иди нахуй', 'Сука кудрявая',
    'Твою мать ебал хуесос, ещё раз тегнешь ебало вскрою', '.ид', 'я родился где-то под забором,цыгани окрестили вором',
    'дай обезьяне гранату и она её взорвёт', 'В нарнию отправляешься.',
    'Эх... молод ты мальчик и глуп, ещё не видал больших залуп',
    'Ты был под сумашедшим обстрельным огнем на войне в Афгане, Дашти Морго?',
    'В овраге тебя со споротой шеей найдут, если будешь тегать меня',
    '2 наряда вне очереди\n\nрядовой солдат прибыл чтобы отсосать вам член',
    'Стоят два стула - на одном пики точенные а на втором...', 'Астанавитесь',
    'Быстрее скорости света - жду от твоей мамаши минет', 'В рабстве',
    'Ах... какая же у тебя красивая мама!', 'Ты кто по масти будешь фраер?',
    'Я хоть и ростом мал, но мать твою в очко ебал', 'Ебать ты лось дырявый',
    'котакбас жазба маған', 'жоғалш иттін баласы', 'Хули тебе от меня надо? Пидрила ебаная!',
    'Ишак ебаный блять! Сука кудрявая, ах ты блять а... танцор ебучий, шакал ебаный блять',
    'на кладбище твоей семьи', 'Ритуалю на могиле твоей матери 💀🍷💅🔮', 'Меня в детстве роняли головкой,она опухла и хуй стал боеголовкой',
    'у тебя под дверью', 'педофилю в геншин импакт', 'не тегай меня, блядота, я афк',
    'гробик на колесиках уже выехал за тобой', 'ах ты быдло', 'Чмо болотное',
    'сон дал мне возможность обнять тебя и я сломал тебе шею', 'ты засадишь ей в очко, а она тебя в сезо'
]


class Style:
    hearts = [
        '❤️', '🧡', '💛',
        '💚', '💙', '💜',
        '🖤', '🤍', '💘',
        '❤️‍🔥', '💕', '💞',
        '💓', '💗', '💖'
    ]
    premium_hearts_funny = [
        '<emoji id=5215436954274899535>💕</emoji>',
        '<emoji id=5341749008987594957>💖</emoji>',
        '<emoji id=5470099064336952325>🎀</emoji>',
        '<emoji id=5474216383195655940>😒</emoji>',
        '<emoji id=6037075682742242567>💓</emoji>',
        '<emoji id=6037598509111184623>❣️</emoji>',
        '<emoji id=5440401156486483437>💃</emoji>',
        '<emoji id=5440534283292779018>😶</emoji>',
        '<emoji id=5465262274031659421>🥰</emoji>',
        '<emoji id=5366185465936359346>🤍</emoji>',
        '<emoji id=5352868078021521704>❤️</emoji>',
        '<emoji id=5229091531482211195>💕</emoji>',
        '<emoji id=5427042854713175487>😘</emoji>',
        '<emoji id=5426854593411688257>❤️</emoji>',
        '<emoji id=5359686514697576863>⭐️</emoji>',
        '<emoji id=5359815299291948356>💖</emoji>',
        '<emoji id=5362034079397060625>🫤</emoji>',
        '<emoji id=5361537499573262669>💎</emoji>',
        '<emoji id=5361962555306681814>🦋</emoji>',
        '<emoji id=5361964384962748478>💓</emoji>',
        '<emoji id=5377688663960331522>💙</emoji>',
        '<emoji id=5377381462129518695>💙</emoji>',
        '<emoji id=5377366996679670959>⭐️</emoji>',
        '<emoji id=5314341774699802956>🦋</emoji>',
        '<emoji id=5474253027856623827>💛</emoji>',
        '<emoji id=5474340666664299721>🎀</emoji>',
        '<emoji id=5474241190926755356>🌟</emoji>',
        '<emoji id=5301049851646058823>❤️</emoji>',
        '<emoji id=5212952152485405360>🖤</emoji>',
        '<emoji id=5264712044615049737>🤍</emoji>',
        '<emoji id=5195263303907026995>💕</emoji>',
        '<emoji id=5474264426699823831>😘</emoji>',
        '<emoji id=5411101864550736013>🦋</emoji>',
        '<emoji id=5323327026671657084>🦋</emoji>',
        '<emoji id=5406777639937516095>💕</emoji>',
        '<emoji id=5384369627323177947>😘</emoji>',
        '<emoji id=4983596565256995556>❤️</emoji>',
        '<emoji id=5361771558111028060>🤩</emoji>',
        '<emoji id=5362081079224180363>❤️</emoji>',
        '<emoji id=5361979846845014099>💃</emoji>',
        '<emoji id=5362088337718909649>🫢</emoji>',
        '<emoji id=5449764172306853865>☺</emoji>',
        '<emoji id=5449609794002427162>🤩</emoji>',
        '<emoji id=5449808084052491771>😴</emoji>',
        '<emoji id=5213147732411166227>💓</emoji>',
        '<emoji id=5215377245639549895>💎</emoji>',
        '<emoji id=5426983309286581320>🔫</emoji>',
        '<emoji id=5456218503130392490>✨</emoji>',
    ]
    premium_hearts_cry = [
        '<emoji id=5449877486429024871>😭</emoji>',
        '<emoji id=5355069308890258814>😭</emoji>',
        '<emoji id=5472088707936820483>😭</emoji>',
        '<emoji id=5368314927901580908>😭</emoji>',
        '<emoji id=5472125180799098428>😭</emoji>',
        '<emoji id=5449362017339059466>😭</emoji>',
        '<emoji id=5409267707356915008>😢</emoji>',
        '<emoji id=5409131758757093889>😔</emoji>',
        '<emoji id=5366572300755804133>🥺</emoji>',
        '<emoji id=5368675799643726437>🫣</emoji>',
        '<emoji id=5298505616099123089>🥺</emoji>',
        '<emoji id=5362033353547587346>😭</emoji>',
        '<emoji id=5370936064837950909>😳</emoji>',
        '<emoji id=5197464109574006643>😭</emoji>',
        '<emoji id=6034869486891306829>😭</emoji>',
        '<emoji id=5193011121841254067>😭</emoji>',
        '<emoji id=5310074647381814457>😭</emoji>',
        '<emoji id=5264980218078044648>😭</emoji>',
        '<emoji id=5310280981905681126>😭</emoji>',
        '<emoji id=5346182136791570916>😭</emoji>',
        '<emoji id=5305315699063792809>😭</emoji>',
        '<emoji id=5447275822874373437>😭</emoji>',
        '<emoji id=5348070754170711054>😭</emoji>',
        '<emoji id=6328097010247272284>😭</emoji>',
        '<emoji id=6327887020706235691>😭</emoji>',
        '<emoji id=6327887020706235691>😭</emoji>',
        '<emoji id=5346002310805855917>😭</emoji>',
        '<emoji id=5310291392906405602>😭</emoji>',
        '<emoji id=5785001440799887135>😭</emoji>',
    ]
    premium_zar = [
        '<emoji id=5411101864550736013>🦋</emoji>',
        '<emoji id=5352613480950143804>🦋</emoji>',
        '<emoji id=5345794417208861153>🦋</emoji>',
        '<emoji id=5345844706980929350>🦋</emoji>',
        '<emoji id=5377520614774939920>🦋</emoji>',
        '<emoji id=5361866446823497727>🦋</emoji>',
        '<emoji id=5409326788927037287>🦋</emoji>'
    ]
    flowers = ['🌷', '🌹', '🥀', '🪷', '🌺', '🌸', '🌱', '🌿']
    reactions_hearts = ['💘', '❤️', '🍓', '❤️\u200d🔥', '💋', '🎉']
    bio_resource = '🧬'
    zap_heart = '💗'
    clock = '⏳'
    exclusion_on = '💌'
    exclusion_off = '✉️'
    little_stars = '✨'
    prem_star = '<emoji id=5330425370661363091>✅</emoji>'
    prem_nom_writing = '<emoji id=5408952100275101991>✏️</emoji>'
    pencil = '✏️'
    prem_nom_magic_wand = '<emoji id=5408827082367053055>🪄</emoji>'
    prem_duck_cleaning = '<emoji id=5472291748220771063>🧹</emoji>'
    page_with_curl = '📃'
    prem_redis_think = '<emoji id=5472104564956077744>🤔</emoji>'
    grey_question = '❔'
    magic_wand = '🪄'
    prem_nom_king = '<emoji id=5341590541874242502>🪑</emoji>'
    microscope = '🔬'

class StyleTexts:
    zar_text_funny = [
        'Удивительно',
        'Спасибо',
        'Спасибки',
        'Прелесть',
        'Thanks',
        'Danke',
        'Merci',
        'Замечательно',
        'Великолепно',
        'Отлично',
        'Идеально',
        'Потрясающе',
        'Блестяще',
        'Фантастически',
        'Чудесно',
        'Превосходно',
        'Безупречно',
        'Грандиозно',
        'Восхитительно',
        'Ослепительно',
        'Изумительно',
        'Завораживающе',
    ]
    zar_text_crying = [
        'Печаль',
        'Скорбь',
        'Кричу',
        'Расстраиваюсь',
        'Грущу',
        'Плачу',
        'Тоска',
        'Меланхолия',
        'Забвение',
        'Отчаяние',
        'Безнадежность',
        'Расстройство',
        'Подавленность',
        'Опустошение',
        'Сумрачность',
        'Беспокойство',
        'Потерянность',
        'Надежды угасают',
        'Беспомощность',
        'Внутренняя боль',
        'Безрадостность',
        'Ужасно',
        'Неудачно',
        'Негативно',
        'Мизерно',
        'Неприемлемо',
        'Скверно',
        'Грозно',
        'Низкокачественно',
        'Отвратительно',
        'Хуево',
        'Так себе',
        'Хуета',
        'Мрачно',
        'Катастрофически',
        'Неудовлетворительно',
        'Жалко',
        'Бесперспективно',
        'Пагубно',
        'Зловеще',
        'Подавляюще',
        'Отрицательно',
    ]

