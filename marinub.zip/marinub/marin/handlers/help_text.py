from config import f_config, Me, black_iris, Style
from storage.storage import Settings, ctimer, cycle_timers
from functions import func
from loader import app

from pyrogram import Client, filters
from pyrogram.types import Message

import asyncio, re, random


# Info and help
@app.on_message(filters.text, group = 5)
async def info(app: Client, msg: Message):
    
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted or msg.from_user and msg.from_user.id == Me.me.id:
        entity = msg.chat.id
        
        msgt = msg.text
        msgtl = msg.text.lower()
        me_name = Me.me.first_name
        
        if msg.reply_to_message:
            msgr = msg.reply_to_message
            if not msgr or not msgr.text: return
            msgrt = msgr.text
            msgrtl = msgrt.lower()
        
        se_prefix = Settings.prefix.upper()
        se_name = func.up_first_word(Settings.name)
        if Settings.sex == 'он':
            sex = 'мальчик'
        else:
            sex = 'девочка'
        
        season = random.choice(Style.flowers)
        hearts = random.choice(Style.hearts)
        
        if (msgtl == 'мой свиток' and msg.from_user.id == Me.me.id or re.fullmatch(r'{} (свиток|хелп|инфа|инфо|помощь|команды)'.format(re.escape(Settings.name)), msgtl)) and not msg.reply_to_message:
            temp = await msg.reply((
                f'<b>{season} Свиток <a href="tg://openmessage?user_id={Me.me.id}">{me_name}</a></b>\n\n'
                
                f'<i>📝 Информация обо мне <code>{se_name} досье</code></i>\n'
                f'<i>🗡 Таланты <code>{se_name} таланты</code></i>\n'
                
                f'<i>🩸 Душегуб <code>{se_name} душегуб</code></i>\n'
                f'<i>🦠 Менеджер жертв <code>{se_name} оп</code></i>\n'
                f'<i>📃 Списки <code>{se_name} списки</code></i>\n\n'
                
                f'<i>💕 Доверенности <code>{se_name} дов</code></i>\n'
                f'<i>🔐 Права доступа <code>{se_name} дос</code></i>\n'
                f'<i>⌛️ Циклический таймер <code>{se_name} цт</code></i>\n\n'
                f'<i>🍬 Калькулятор <code>!Calc</code></i>\n'
                f'<i>🎁 Special <code>!Special</code></i>\n'
                f'<b>{hearts} @Scroogees</b>\n\n'
                
                f'Префикс <b>{se_prefix}</b>, имя <b>{func.up_first_word(Settings.name)}</b>, пол <b>{sex}</b>\n'
            ))
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'{Settings.name} досье' and not msg.reply_to_message:
            temp = await msg.reply(
                f'<b>📝 Информация обо мне</b>\n'
                '<i>изменения моего префикса, имени и пола</i>\n\n'
                
                f'<code>мой свиток</code><i> / </i><code>{se_name} свиток</code><i>|</i><code>инфа</code><i>|</i><code>хелп</code><i>|</i><code>команды</code><i> свиток</i>\n'
                f'<code>!довы</code><i> созвать владельцев довов показав их префиксы</i>\n'
                f'<code>.{se_prefix}преф И</code><i> / </i><code>.преф И</code><i> назначить префикс</i>\n'
                f'<code>.{se_prefix}нейм Маск</code><i> / </i><code>.нейм Маск</code><i> назначить имя</i>\n'
                f'<code>.{se_prefix}пол он/она</code><i> изменить ваш пол</i>'
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
            
        if msgtl == f'{Settings.name} таланты' and not msg.reply_to_message:
            temp = await msg.reply(
                f'<b>🗡 Таланты</b>\n'
                '<i>основные навыки</i>\n\n'
                
                '<i>__Infect__</i>\n'
                f'<code>{se_prefix}б @777000</code><i> заразить</i>\n'
                f'<code>{se_prefix}зл 1 3-5 50</code> <i>заразить список</i>\n'
                f'<code>{se_prefix}зл (3с/2.5с)</code> <i>установить задержку для заражений по списку(3.5с обычно)</i>\n'
                f'<code>{se_prefix}з -/=/+ 0-99</code> <i>цикличная заражалка -/+/=</i>\n'
                '<i>^</i>\n'
                f'<code>{se_prefix}х</code><i> / </i><code>Хил</code><i> исцелиться</i>\n'
                f'<code>{se_prefix}л</code><i> моя лаборатория</i>\n'
                f'<code>{se_prefix}фа</code><i> силует лаборатории</i>\n'
                f'<code>мои жертвы</code><i> / </i><code>{se_name} жертвы</code><i> моя ежа</i>\n'
                f'<code>{se_prefix}ж</code><i> силует моей ежы</i>\n'
                f'<code>мои болезни</code><i> / </i><code>{se_name} болезни</code><i> мои болезни</i>\n'
                f'<code>+</code><i>|</i><code>-</code> <code>{se_prefix}в</code><i> вирусы в чат</i>\n'
                f'<code>+</code><i>|</i><code>-</code> <code>{se_prefix}пат</code><i> / </i><code>пат</code><i> изменить имя патогена</i>\n'
                f'<code>.{se_prefix}заразность 1-5</code><i> / </i><code>.заразность 1-5</code><i> левелап лаборатории(вторая массовая)</i>\n'
                f'<code>кто reply 1-99</code><i> узнать кто прячется за заражением</i>\n'
                f'<code>!сб 1-999</code><i> свежие болезни чата</i>\n'
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'{Settings.name} душегуб' and not msg.reply_to_message:
            temp = await msg.reply(
                f'<b>🩸 Душегуб</b>\n'
                '<i>тёмный раздел</i>\n\n'
                
                f'<code>{se_name} от</code><i> auto-infecter</i>\n'
                f'<code>{se_name} хил</code><i> авто-исцеление</i>\n'
                f'<code>{se_name} вампир</code><i> вампир</i>'
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        
        if msgtl == f'{Settings.name} оп' and not msg.reply_to_message:
            temp = await msg.reply(
                '<b>🦠 Менеджер жертв</b>\n'
                '<i>все что касается жертв</i>\n\n'
                
                f'<code>{se_prefix}оп link</code><i> / </i><code>Оп link</code><i> приносимый опыт с жертвы</i>\n'
                f'<code>.{se_prefix}о reply</code><i> приносимый опыт с реплайнутой жертвы</i>\n'
                f'<code>+{se_prefix}оп @id 2k</code><i> / </i><code>+оп @id 2k</code><i> добавить или обновить жертву</i>\n'
                f'<code>-{se_prefix}оп @id</code><i> / </i><code>оп @id</code><i> удалить запись о жертве</i>\n'
                f'<code>+</code><i>|</i><code>-</code> <code>{se_prefix}иск @id</code><i> / </i><code>+/-Иск @</code><i> добавить/убрать жертву из исключения</i>\n'
                f'<code>+</code><i>|</i><code>-</code> <code>{se_prefix}иск reply</code><i> / </i><code>+/-иск reply</code><i> добавить/убрать список из исключений</i>\n'
                f'<code>!{se_prefix}иск 2к/авто</code><i> / </i><code>!иск 2к/авто</code><i> добавить/убрать автоисключения от числа опыта</i>\n'
                f'<code>{se_name} зарлист бэкап</code><i> / </i><code>.зарлист бэкап</code><i> список ваших заражений > файл</i>',
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'{Settings.name} списки' and not msg.reply_to_message:
            temp = await msg.reply((
                '<b>📃 Списки</b>\n'
                f'<code>{se_name} .б</code><i> / </i><code>.б</code><i> показывает приносимую и сущ. ежу со списка</i>\n'
                f'<code>{se_name} .б +</code><i> / </i><code>.б +</code><i> заражает в + из списка</i>\n'
                f'<code>{se_name} .б =</code><i> / </i><code>.б =</code><i> заражает новых из списка</i>\n'
                f'<code>{se_name} .е</code><i> / </i><code>.е</code><i> показывает сущ. ежу со списка(NotExec)</i>\n'
                f'<code>{se_prefix}список 1/2</code><i> составляет список из списка</i>\n'
                f'<code>{se_name} +/-апи</code><i> снижает нагрузку на TelegramAPI путем запрета APICall, обнаружение юзеров в списке снижаеться(не рекомендуется при: малой БД жертв или менее 10 дней после установки скрипта;)</i>\n'
                f'<code>{se_name} топ жертв</code><i> / </i><code>топ жертв (пусто|1-*|500-2к)</code><i> топ 100/страницы/n-n ваших жертв</i>\n'
                '<i>^</i>\n'
                '<code>бт</code><i> биотоп</i>\n'
                '<code>бч</code><i> биотоп чата</i>\n'
                '<code>бз</code><i> биотоп заражений</i>\n'
                '<code>бчз</code><i> биотоп чата заражений</i>\n'
                '<code>кт</code><i> корп топ</i>\n'
            ))
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'{Settings.name} дов' and (msg.from_user.id == Me.me.id or Settings.trusted[str(msg.from_user.id)]['access']['dov']) and not msg.reply_to_message:
            text = ''
            for key, val in Settings.trusted.items():
                text += f'<code>-Дов @{key.ljust(11)}</code><a href="tg://openmessage?user?id={key}">«{val["name"]}»</a>\n'
            text = (
                '<b>💕 Доверенности</b>\n'
                f'Мой айди: <code>+Дов @{Me.me.id}</code>\n'
                f'Мои доверенности:\n\n'
                f'{text}\n'
                f'Убрать доверенность <code>-Дов</code> <i>/</i> <code>-{func.up_first_word(Settings.prefix)}дов</code> <code>(@ID/reply)</code>\n'
                f'Добавить доверенность <code>+Дов</code> <i>/</i> <code>+{func.up_first_word(Settings.prefix)}дов</code> <code>(@ID/reply)</code>\n'
            )
            temp = await app.send_message(msg.chat.id, text)
            await msg.delete()
            
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'!calc' and msg.from_user.id == Me.me.id and not msg.reply_to_message:
            temp = await msg.reply((
                '<b>💸 Calculator</b>\n\n'
                
                '<code>.к (аргументы)</code><i> обычный и полезный калькулятор</i>\n\n'
                
                '<code>x + y</code> <i>Сложение (сумма x и y)</i>\n'
                '<code>x - y</code> <i>Вычитание (разница между x и y)</i>\n'
                '<code>-x</code> <i>Смена знака x</i>\n'
                '<code>+x</code> <i>Тождественность x</i>\n'
                '<code>x * y</code> <i>Умножение x на y</i>\n'
                '<code>x / y</code> <i>Деление x на y</i>\n'
                '<code>x // y</code> <i>Получение целой части от деления x на y</i>\n'
                '<code>x % y</code> <i>Остаток от деления x / y</i>\n'
                '<code>x ** y</code> <i>Возведение в степень</i>\n\n'
    
                '<b>🍬 Candy calculator</b>\n\n'
    
                '<i>.к (start) (type) (finish)</i>\n'
                '<i>.д (profit) (days)</i>\n'
                '<i>.д (profit) (first) (type) (second)</i>\n\n'
    
                '<b>Типы:</b>\n'
                '<code>патоген</code>, <code>пат</code>\n'
                '<code>квалификация</code>, <code>квала</code>\n'
                '<code>заразность</code>, <code>зз</code>\n'
                '<code>иммунитет</code>, <code>имун</code>, <code>иммун</code>\n'
                '<code>летальность</code>, <code>летал</code>\n'
                '<code>безопасность</code>, <code>сб</code>\n\n'
                
                '<b>Примеры:</b>\n'
                '<code>.з 10 зз 100</code> -> с 10 уровня заразности до 100\n'
                '<b>💵 Улучшение с </b>10<b> до </b>100<b> заразности стоит: </b>2.906.282<b> био-ресурсов<b>\n\n'
                
                '<code>.д 12к 10</code> -> 12 тысяч на 10 дней\n'
                '<b>💵 За </b>10<b> дней, вы заработаете - </b>120.000<b> био-ресурсов.</b>\n\n'
                
                '<code>.д 12к 10 зз 30</code> -> 12 тысяч, 10 уровень заразности и 30 уровень\n'
                '<b>💵 Вам понадобится </b>1<b> дней, чтобы прокачать зз на </b>30<b> уровень.</b>\n\n'
                
                '<i>Максимальный лимит высчитываемой прокачки 1000</i>\n'
                '<i>^Отдельное спасибо за дизайн и идею > @iris_calc_bot</i>'
                ))
            asyncio.create_task(func.delete_msg([msg, temp], 3 * 60))
        
        if msgtl == '!special' and msg.from_user.id == Me.me.id and not msg.reply_to_message:
            temp = await msg.reply(
                '<b>🎁 Special</b>\n'
                '<i>Отдельный раздел с косметическими украшениями</i>\n\n'
                '<code>!thanks</code><i> спасибки при заражении</i>\n'
                '<code>!reaction</code><i> реакции при заражении</i>\n'
                f'<code>где {se_name}</code><i> зовет ваших доверок</i>\n'
                f'<code>!где милый/грубый/рандом</code><i> настраивает тип ответов</i>\n'
                '<code>!рестарт</code><i> перезапуск юзербота</i>\n'
                '<code>!visual_victims</code> <i>визуальная запись жертв</i>\n'
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        ###
        
        if msgtl == f'{Settings.name} цт' and (msg.from_user.id == Me.me.id or Settings.trusted[str(msg.from_user.id)]['access']['ctimer']) and not msg.reply_to_message:
            timers = ''
            for key in ctimer.read['cycle_timers']:
                timer = ctimer.read['cycle_timers'][key]
                if timer:
                    time_count = int(timer["delay"])
                    if time_count < 60:
                        time_count = f'{time_count} секунд'
                    else:
                        time_count = f'{int(time_count/60)} минут'
                    timers += f'{key[-1]}. <b>{timer["chat"]["title"]}</b> каждые {time_count} повторяю <i>{timer["job"]}</i>\n'
            if timers == '':
                timers = 'пуст\n'
            temp = await msg.reply(
                f'<b>⏳ Циклический таймер</b>\n'
                f'<code>+{se_prefix}цт (чч:мм) (любой текст)</code><i> / </i><code>+цт (чч:мм) (любой текст)</code><i> добавить циклический таймер</i>\n'
                f'<code>-{se_prefix}цт 1-8</code><i> / </i><code>-цт 1-8</code><i> удалить циклический таймер</i>\n\n'
                'Список таймеров:\n'
                f'{timers}'
                f'<i>Лимит 8 цтаймеров</i>',
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        
        # Права доступа
        if msgtl == f'{Settings.name} дос' and msg.from_user.id == Me.me.id and not msg.reply_to_message:
            text = ''
            for key, val in Settings.trusted.items():
                bio_entity = f'<a href="tg://openmessage?user_id={key}">{val["name"]}</a>'
                lab = str(val['access']['lab']).replace('False', 'no').replace('True', 'yes')
                lvl_lab = str(val['access']['lvl_lab']).replace('False', 'no').replace('True', 'yes')
                victims = str(val['access']['victims']).replace('False', 'no').replace('True', 'yes')
                timer = str(val['access']['ctimer']).replace('False', 'no').replace('True', 'yes')
                dov = str(val['access']['dov']).replace('False', 'no').replace('True', 'yes')
                vampir = str(val['access']['vampir']).replace('False', 'no').replace('True', 'yes')
                where_trigger = str(val['access']['where_trigger']).replace('False', 'no').replace('True', 'yes')
                infection = str(val['access']['infection']).replace('False', 'no').replace('True', 'yes')
                text += (
                f'{bio_entity} '
                f'<code>{lab}</code> '
                '<i>&</i> '
                f'<code>{lvl_lab}</code> '
                '<i>&</i> '
                f'<code>{victims}</code> '
                '<i>&</i> '
                f'<code>{timer}</code> '
                '<i>&</i> '
                f'<code>{dov}</code> '
                '<i>&</i> '
                f'<code>{vampir}</code> '
                '<i>&</i> '
                f'<code>{where_trigger}</code> '
                '<i>&</i> '
                f'<code>{infection}</code>\n'
                )
            temp = await msg.reply(
                '<b>🔐 Права доступа</b>\n'
                'Доступ к лабе <code>лаб</code>\n'
                'Доступ к прочачке лабы <code>аплаб</code>\n'
                'Доступ к еже <code>ежа</code>\n'
                'Доступ к цтаймерам <code>цт</code>\n'
                'Доступ к доверкам <code>дов</code>\n'
                'Доступ к вампиру <code>вампир</code>\n'
                'Доступ к где <code>где</code>\n'
                'Доступ к заражениям <code>зар</code>\n\n'
                
                '<b>Дов</b> <i>&</i> <b>лаба</b> <i>&</i> <b>аплаб</b> <i>&</i> <b>ежа</b> <i>&</i> <b>цтаймер</b> <i>&</i> <b>дов</b> <i>&</i> <b>вампир</b> <i>&</i> <b>где</b> <i>&</i> <b>зар</b>\n'
                f'{text}\n\n'
                
                f'<code>дос (префикс)</code><i> измениить доступ к умению</i>\n'
                f'<code>дос (префикс) (@id/reply)</code><i> изменить доступ к умению для определенных доверок</i>',
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'{Settings.name} от' and not msg.reply_to_message:
            ao = 'Выключен'
            if str(msg.chat.id) in Settings.autoanswer_chats and Settings.autoanswer_chats[str(msg.chat.id)]['autoanswer'] == 'True':
                ao = 'Включен'
            aotis = str(Settings.autoanswer_time).split(' ')
            if len(aotis) >= 2:
                aoits_output = f'{aotis[0]}-{aotis[1]}'
            else:
                aoits_output = aotis[0]
            
            acl_result = ''
            for key, val in Settings.autoanswer_chats.items():
                if val['autoanswer'] == 'True':
                    acl_result += f'<code>{key}</code> <i>{val["chat_title"]}</i>\n'
            if acl_result == '':
                acl_result = 'Нету'
            
            if Settings.autoanswer_chat != 'False' and Settings.autoanswer_chat in Settings.autoanswer_chats:
                chat_send_infects = f'<b><a href="tg://openmessage?user_id={Settings.autoanswer_chat}">{Settings.autoanswer_chats[Settings.autoanswer_chat]["chat_title"]}</a></b>'
            else:
                chat_send_infects = '<code>Выключен</code>'
            
            random_infects = ('Включены' if Settings.autoanswer_random else 'Выключены')
            
            temp = await msg.reply((
                '<b>🩸 Auto-infecter</b>\n'
                f'<code>+/-{se_prefix}от</code><i> / </i><code>+От</code><i> вкл./выкл. AI</i>\n'
                f'<code>{se_prefix}от 15с</code><i> / </i><code>-От 15с</code><i> отвечать через N секунд</i>\n'
                f'<code>{se_prefix}от 6-15с</code><i> / </i><code>От 6-15с</code><i> отвечать с плавающими N секундами</i>\n'
                f'<code>{se_prefix}от N</code><i> / </i><code>От N</code><i> отвечать через каждые N числа раз</i>\n'
                f'<code>{se_prefix}от рандом</code><i> / </i><code>От рандом</code><i> отвечать рандомно каждый раз</i>\n'
                f'<code>{se_prefix}от (-чат|чат|-111)</code><i> / </i><code>От (-чат|чат|-111)</code><i> Отключить/Установить чат для кидания заражений ai</i>\n'
                f'<code>{se_prefix}отч</code><i> / </i><code>Отч</code><i> удалить AI из всех чатов</i>\n\n'
                
                f'<b>Статус AI в чате:</b> <code>{ao}</code>\n'
                f'Таймер работает через: <code>{aoits_output}</code><i> секунд</i>\n'
                f'Умный AI работает через: <code>{int(Settings.autoanswer_everytime)-1}</code><i> раз</i>\n'
                f'Рандомные заражения: <code>{random_infects}</code>\n'
                f'Чат для кидание заражений: {chat_send_infects}\n'
                f'<b>Чаты:</b>\n'
                f'{acl_result}'
            ))
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == f'{Settings.name} хил' and not msg.reply_to_message:
            autoheal = autoheal_full = autoheal_parted = autoheal_random = '❌'
            if Settings.autoheal:
                autoheal = '💚'
            if Settings.autoheal_full:
                autoheal_full = '💚'
            if Settings.autoheal_parted != 0:
                autoheal_parted = '💚'
            if Settings.autoheal_random:
                autoheal_random = '💚'
            temp = await msg.reply(
                '<b>💉 Авто-исцеление</b>\n'
                f'<code>+{se_prefix}хил</code><i> включает/отключает авто-исцеление</i>\n'
                f'<code>{se_prefix}хил фул</code><i> полное исцеление, более точное но тратит больше ресурсов(10 бол. - 10 вакцин)</i>\n'
                f'<code>{se_prefix}хил 3</code><i> режим экономии, покупает вакцину через каждые N болезней(10 бол. - 3 вакцин)</i>\n'
                f'<code>{se_prefix}хил рандом</code><i> покупает вакцину рандомно(10 бол. - ? вакцин)</i>\n'
                '<i>Если авто-исцеление отключить, в таком случае вакцина будет покупатся только при - AI, заражению по спискам</i>\n\n'
                
                'Состояние авто-исцеления:\n'
                f'<i>{autoheal}Авто-исцеление</i>\n'
                f'<i>{autoheal_full}Полное исцеление</i>\n'
                f'<i>{autoheal_parted}Частичное исцеление</i>\n'
                f'<i>{autoheal_random}Рандомное исцеление</i>',
            )
            asyncio.create_task(func.delete_msg(temp, 2 * 60))
        
        if msgtl == f'{Settings.name} вампир' and not msg.reply_to_message:
            if Settings.vampir:
                if Settings.trusted[str(msg.from_user.id)]['access']['vampir']:
                    temp = await msg.reply(
                        '<b>🧛‍♂️ Вампир</b>\n'
                        f'<code>{se_name} ап</code><i> автозаражения в плюс</i>\n'
                        f'<code></code><i></i>\n'
                        f'<code></code><i></i>\n'
                        f'<code></code><i></i>\n'
                    )
                    asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
            else:
                temp = await msg.reply('<b>🔒 ACCESS DENIED</b> Вы не являетесь участником корпорации создателя юзербота')
                asyncio.create_task(func.delete_msg([msg, temp], 16))

        if msgtl == f'{Settings.name} ап' and Settings.vampir and Settings.trusted[str(msg.from_user.id)]['access']['vampir'] and not msg.reply_to_message:
            
            if str(Settings.auto_infecter_chat_sync) in Settings.autoanswer_chats:
                title = Settings.autoanswer_chats[str(Settings.auto_infecter_chat_sync)]['chat_title']
            else:
                title = Settings.auto_infecter_chat_sync
            sync_chat =f'<a href="tg://openmessage?user_id={Settings.auto_infecter_chat_sync}">{title}</a>'
            
            chats_ap = dict([(key, val) for key, val in Settings.autoanswer_chats.items() if 'auto_infecter_chat' in val and val['auto_infecter_chat'] == 'True'])
            chat_entities = []
            for key, val in chats_ap.items():
                chat_entities.append(f'<a href="tg://openmessage?user_id={key}">{val["chat_title"]}</a>')
            
            autoplus_chat = '<code>Выключен</code>'
            if Settings.auto_infecter_chat != 'False':
                autoplus_chat = f'<code>{Settings.auto_infecter_chat}</code>'
                if Settings.auto_infecter_chat in Settings.autoanswer_chats:
                    autoplus_chat = f'<b><a href="tg://openmessage?user_id={Settings.auto_infecter_chat}">{Settings.autoanswer_chats[Settings.auto_infecter_chat]["chat_title"]}</a></b>'
            
            temp = await msg.reply(
                '<b>🧛‍♂️ АП</b>\n'
                f'<code>+{se_prefix}ао</code> <i>вкл./выкл ао</i>\n'
                f'<code>{se_prefix}ао доп</code> <i>вкл./выкл. сиинхронизацию с биотопами</i>\n'
                f'<code>{se_prefix}ао 30%</code> <i>назначить минимум процент для заражений(30%)</i>\n'
                f'<code>{se_prefix}ао 3-12с</code> <i>назначить делей в секундах</i>\n'
                f'<code>{se_prefix}ао чат</code> <i>установить чат, для кидалки доп. заражений</i>\n'
                f'<code>{se_prefix}аоч</code> <i>установить чат, для кидалки ао+ заражений\n\n'
                
                f'<i><b>Чаты:</b></i> {", ".join(chat_entities)}\n'
                f'<i>Синхронизация с биотопами:</i> <code>{("Включена" if Settings.auto_infecter_sync else "Выключена")}</code>\n'
                f'<i>Минимальный процент для заражения:</i> <code>{Settings.auto_infecter_percent}%</code>\n'
                f'<i>Делей:</i> <code>{Settings.auto_infecter_time}с</code>\n'
                f'<i>Чат для кидалки доп. заражений:</i> <b>{sync_chat}</b>\n'
                f'<i>Чат для кидалки ао+ заражений:</i> {autoplus_chat}'
            )
            asyncio.create_task(func.delete_msg([msg, temp], 2 * 60))
        
        if msgtl == '!довы' and not msg.reply_to_message:
            if msg.from_user.id != Me.me.id:
                temp = await msg.reply(
                    f'Префикс <b>{se_prefix}</b>, имя <b>{func.up_first_word(Settings.name)}</b>, пол <b>{sex}</b>',
                )
                asyncio.create_task(func.delete_msg([msg, temp], 30))
        
        
        # префикс для доверки
        if re.fullmatch(r'\.{}преф [\w\d,\./]+'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'\.преф [\w\d,\./]+', msgtl) and msg.from_user.id == Me.me.id:
            pref = msgtl.split(' ')[1]
            func.edit_cf(f_config, 'user_settings', 'prefix', pref)
            Settings.refresh(f_config)
            temp = await msg.reply(f'Ваш префикс <b>{pref}</b>')
            asyncio.create_task(func.delete_msg([msg, temp], 30))
        
        # мое имя
        if re.fullmatch(r'\.{}нейм [\w]+'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'\.нейм [\w]+', msgtl) and msg.from_user.id == Me.me.id:
            name = msgtl.split(' ')[1]
            temp = await msg.reply(f'Ваше прозвище - <b>{func.up_first_word(name)}</b>')
            func.edit_cf(f_config, 'user_settings', 'name', name)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 30))
        
        if re.fullmatch(r'\.{}пол (он|она)'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'\.пол (он|она)', msgtl) and msg.from_user.id == Me.me.id:
            parts = msgtl.split(' ')
            if parts[1] == 'он':
                sex = 'мальчик'
                appeal = 'Господин'
                emodji = '🎩'
            else:
                sex = 'девочка'
                appeal = 'Госпожа'
                emodji = '👠'
            temp = await msg.reply(f'<i>{emodji} Ваш пол успешно изменен на <i><b>«{sex}»</b>\n<i>^{appeal} {se_name}</i>')
            func.edit_cf(f_config, 'user_settings', 'sex', parts[1])
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 30))


#