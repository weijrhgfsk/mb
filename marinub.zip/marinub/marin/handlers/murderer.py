from config import f_config, Me, trusted_f, f_chats_config, all_iris, black_iris, ub_admin
from storage.storage import Settings
from functions import func
from loader import app
from handlers.autoheal import autoheal

from pyrogram import Client, filters
from pyrogram.handlers import MessageHandler
from pyrogram.types import Message

import asyncio, json, re


### Душегуб ###

@app.on_message(filters.text, group = 2)
async def autoanswer(app: Client, msg: Message):

    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
        
        entity = msg.chat.id
    
        msgt = msg.text
        msgtl = msg.text.lower()
        
        # Включить АО
        if msgtl == f'+{Settings.prefix}от' or msgtl == f'+от':
            chat_title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
            if str(msg.chat.id) in Settings.autoanswer_chats and Settings.autoanswer_chats[str(msg.chat.id)]['autoanswer'] == 'True':
                temp = await app.send_message(entity, f'<i>🤨 AI в чате</i> <code>«{chat_title}»</code> <i>уже включен</i>')
            else:
                temp = await app.send_message(entity, f'<i>✅ AI в чате</i> <code>«{chat_title}»</code> <i>включен</i>')
                this_chat = str(msg.chat.id)
                func.chats_config_append({this_chat: {'chat_title': chat_title, 'autoanswer': 'True'}}, f_chats_config)
                Settings.refresh(f_config)
            await msg.delete()
            asyncio.create_task(func.delete_msg(temp, 3))
        
        # Выключить АО
        elif msgtl == f'-{Settings.prefix}от' or msgtl == f'-от':
            chat_title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
            if str(msg.chat.id) not in Settings.autoanswer_chats or str(msg.chat.id) in Settings.autoanswer_chats and Settings.autoanswer_chats[str(msg.chat.id)]['autoanswer'] == 'False':
                temp = await app.send_message(entity, f'<i>🤨 AI в чате</i> <code>«{chat_title}»</code> <i>уже выключен</i>')
            else:
                temp = await app.send_message(entity, f'<i>❌ AI в чате</i> <code>«{chat_title}»</code> <i>выключен</i>')
                this_chat = str(msg.chat.id)
                func.chats_config_append({this_chat: {'chat_title': chat_title, 'autoanswer': 'False'}}, f_chats_config)
                Settings.refresh(f_config)
            await msg.delete()
            asyncio.create_task(func.delete_msg(temp, 3))
        
        # отвечать через N секунд
        elif re.fullmatch(r'{}от \d+с'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'от \d+с', msgtl) and msg.from_user.id == Me.me.id:
            time = (msgt.split(' ')[1])[:-1]
            func.edit_cf(f_config, 'user_settings', 'autoanswer_time', str(time))
            Settings.refresh(f_config)
            temp = await msg.reply(f'Поставлен таймер на <code>{time}</code> секунд')
            asyncio.create_task(func.delete_msg([msg, temp], 7))
        
        # отвечать с плавающими N секундами
        elif re.fullmatch(r'{}от \d+-\d+с'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'от \d+-\d+с', msgtl) and msg.from_user.id == Me.me.id:
            time = ''.join(msgt.split(' ')[1]).replace('с', '').split('-')
            func.edit_cf(f_config, 'user_settings', 'autoanswer_time', f'{time[0]} {time[1]}')
            Settings.refresh(f_config)
            temp = await msg.reply(f'Поставлен плавающих таймер, между <code>{time[0]}-{time[1]}</code> секунд')
            asyncio.create_task(func.delete_msg([msg, temp], 7))
        
        # отвечать через каждые N числа раз
        elif re.fullmatch(r'{}от \d+'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'от \d+', msgtl) and msg.from_user.id == Me.me.id:
            time = int(msgtl.split(' ')[1]) + 1
            func.edit_cf(f_config, 'user_settings', 'autoanswer_everytime', str(time))
            Settings.refresh(f_config)
            temp = await msg.reply(f'AI теперь отвечает через <code>{str(time-1)}</code> раз')
            asyncio.create_task(func.delete_msg([msg, temp], 7))
        
        # отвечать рандомно
        elif re.fullmatch(r'{}от рандом'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'от рандом', msgtl) and msg.from_user.id == Me.me.id:
            if Settings.autoanswer_random:
                func.edit_cf(f_config, 'user_settings', 'autoanswer_random', 'False')
                text = '❌ Рандомные заражения выключены'
            else:
                func.edit_cf(f_config, 'user_settings', 'autoanswer_random', 'True')
                text = '🎲 Рандомные заражения включены'
            Settings.refresh(f_config)
            temp = await msg.reply(text)
            asyncio.create_task(func.delete_msg([msg, temp], 7))
        
        # Установить чат для кидания заражений
        elif re.fullmatch(r'{}от (-чат|чат|((-|)\d+))'.format(re.escape(Settings.prefix)), msgtl) \
        or re.fullmatch(r'от (-чат|чат|((-|)\d+))', msgtl) and msg.from_user.id == Me.me.id:
            chat_id = msgt.split(' ')[1]
            if chat_id == '-чат':
                chat_id = 'False'
                text = '📄 Чат для кидание заражений выключен'
            else:
                if '-' in chat_id:
                    try:
                        chat_entity = await app.get_chat(chat_id)
                        title = (chat_entity.title if chat_entity.title else chat_entity.first_name)
                    except:
                        title = None
                else:
                    chat_id = str(msg.chat.id)
                    title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
                if title:
                    chat_tag = f'<b><a href="tg://openmessage?user_id={chat_id}">{title}</a></b>'
                else:
                    chat_tag = f'<code>{chat_id}</code>'
                text = f'📜 {chat_tag} назначен чатом для кидание заражалок'
            func.edit_cf(f_config, 'user_settings', 'autoanswer_chat', chat_id)
            Settings.refresh(f_config)
            temp = await msg.reply(text)
            asyncio.create_task(func.delete_msg([msg, temp], 7))
        
        # удалить ао из всех чатов
        elif msgtl == f'{Settings.prefix}отч' or msgtl == 'отч':
            val_ = 0
            with open(f_chats_config, 'r', encoding='utf-8') as fr:
                dictionary = json.load(fr)
            for key, val in dictionary.items():
                if 'autoanswer'in val and val['autoanswer'] == 'True':
                    dictionary[key] = {
                        'chat_exclusion': val['chat_exclusion'],
                        'autoanswer': 'False'
                    }
                    val_ += 1
            with open(f_chats_config, 'w', encoding='utf-8') as fW:
                json.dump(dictionary, fW, indent=4)
            
            temp = await msg.reply(f'<b>🧹 AI очищено из </b>{val_}<b> чатов</b>')
            
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 12))


@app.on_message(filters.text, group = 4)
async def autoheal_active(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msg.text.lower()
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
        
        # off/on auto-heal
        if msgtl == f'+{Settings.prefix}хил':
            if Settings.autoheal:
                text = '❌ Авто-исцеление'
                func.edit_cf(f_config, 'user_settings', 'autoheal', 'False')
            else:
                text = '💚 Авто-исцеление'
                app.add_handler(MessageHandler(autoheal, filters.text & filters.user(all_iris) & filters.regex(r'заражению')), group = 102)
                func.edit_cf(f_config, 'user_settings', 'autoheal', 'True')
            if Settings.autoheal_full is False and Settings.autoheal_parted == 0 and Settings.autoheal_random is False:
                func.edit_cf(f_config, 'user_settings', 'autoheal_full', 'True')
            temp = await msg.reply(text)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 12))
        
        # settings
        # fully heal
        if msgtl == f'{Settings.prefix}хил фул':
            if Settings.autoheal_full:
                text = '❌ Полное исцеление'
                func.edit_cf(f_config, 'user_settings', 'autoheal_full', 'False')
            else:
                text = '💚 Полное исцеление'
                func.edit_cf(f_config, 'user_settings', 'autoheal_full', 'True')
            temp = await msg.reply(text)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 12))
        # parted heal
        if re.fullmatch(r'{}хил \d+'.format(re.escape(Settings.prefix)), msgtl):
            num = msgt.split(' ')[1]
            if len(num) > 2:
                return
            if int(num) == 0:
                text = '❌ Частичное исцеление'
            else:
                text = f'❣️ Частичное исцеление выставлено на {num} пропуска'
            temp = await msg.reply(text)
            func.edit_cf(f_config, 'user_settings', 'autoheal_parted', num)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 12))
        # random heal
        if msgtl == f'{Settings.prefix}хил рандом':
            if Settings.autoheal_random:
                text = '❌ Рандомное исцеление'
                func.edit_cf(f_config, 'user_settings', 'autoheal_random', 'False')
            else:
                text = '💗 Рандомное исцеление'
                func.edit_cf(f_config, 'user_settings', 'autoheal_random', 'True')
            temp = await msg.reply(text)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 12))

@app.on_message(filters.text, group = 8)
async def auto_infecter(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msg.text.lower()
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted and Settings.vampir and (Settings.trusted[str(msg.from_user.id)]['access']['vampir'] or msg.from_user.id == Me.me.id):
        
        if msgtl == f'+{Settings.prefix}ао':
            
            chat = msg.chat.id
            title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
            chat_tag = f'<a href="tg://openmessage?user_id={chat}">{title}</a>'
            
            if str(chat) in Settings.autoanswer_chats and 'auto_infecter_chat' in Settings.autoanswer_chats[str(chat)] and Settings.autoanswer_chats[str(chat)]['auto_infecter_chat'] == 'True':
                aic_val = 'False'
                text = f'❌📜 <b>{chat_tag}</b> вынесен из списка'
            else:
                aic_val = 'True'
                text = f'📜 <b>{chat_tag}</b> внесен в список'
            temp = await msg.reply(text)
            
            func.chats_config_append({str(chat): {'chat_title': title, 'auto_infecter_chat': aic_val}}, f_chats_config)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 4))

        if msgtl == f'{Settings.prefix}аоч':
            if Settings.auto_infecter_chat != 'False':
                func.edit_cf(f_config, 'user_settings', 'auto_infecter_chat', 'False')
                text = '❌ Чат ответок ао+ выключен'
            else:
                func.edit_cf(f_config, 'user_settings', 'auto_infecter_chat', str(msg.chat.id))
                text = '✅ Чат ответок ао+ установлен'
            Settings.refresh(f_config)
            temp = await msg.reply(text)
            asyncio.create_task(func.delete_msg([msg, temp], 4))

        if msgtl == f'{Settings.prefix}ао доп':
            if Settings.auto_infecter_sync:
                func.edit_cf(f_config, 'user_settings', 'auto_infecter_sync', 'False')
                text = 'доп-заражалки выключены'
            else:
                func.edit_cf(f_config, 'user_settings', 'auto_infecter_sync', 'True')
                text = 'доп-заражалки включены'
            Settings.refresh(f_config)
            temp = await msg.reply(text)
            asyncio.create_task(func.delete_msg([msg, temp], 4))

        if re.fullmatch(r'{}ао (-|)\d+%'.format(re.escape(Settings.prefix)), msgtl):
            percent = msgt.split(' ')[1]
            temp = await msg.reply(
                f'Минимальный процент для заражения, изменен <b>{Settings.auto_infecter_percent}%</b> <i>></i> <b>{percent}</b>'
            )
            func.edit_cf(f_config, 'user_settings', 'auto_infecter_percent', percent.replace('%', ''))
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 8))

        if re.fullmatch(r'{}ао (\d+-\d+|\d+)с'.format(re.escape(Settings.prefix)), msgtl):
            time = msgt.split(' ')[1].replace('с', '')
            temp = await msg.reply(
                f'⏳ Делей заражений, изменен <b>{Settings.auto_infecter_time}с</b> <i>></i> <b>{time}с</b>'
            )
            func.edit_cf(f_config, 'user_settings', 'auto_infecter_time', time)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 8))

        if msgtl == f'{Settings.prefix}ао чат':
            chat = msg.chat.id
            title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
            previous_title = f'<code>{Settings.auto_infecter_chat_sync}</code>'
            if str(Settings.auto_infecter_chat_sync) in Settings.autoanswer_chats:
                previous_title = Settings.autoanswer_chats[str(Settings.auto_infecter_chat_sync)]['chat_title']
            previous_chat = f'<a href="tg://openmessage?user_id={Settings.auto_infecter_chat_sync}">{previous_title}</a>'
            new_chat = f'<a href="tg://openmessage?user_id={chat}">{title}</a>'
            temp = await msg.reply(
                f'🦇 Чат для доп-заражалок, изменен <b>{previous_chat}</b> <i>></i> <b>{new_chat}</b>'
            )
            func.edit_cf(f_config, 'user_settings', 'auto_infecter_chat_sync', str(chat))
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 8))
    
    # UB ADMIN ZONE
    if msg.from_user and msg.from_user.id in ub_admin:
        
        if msgtl == '.вампиризм' and msg.reply_to_message and msg.reply_to_message.from_user and msg.reply_to_message.from_user.id == Me.me.id \
        or msgtl == '!вампиризм':
            if Settings.vampir:
                func.edit_cf(f_config, 'user_settings', 'vampir', 'False')
                text = '🦇 Вампиризм убран'
            else:
                func.edit_cf(f_config, 'user_settings', 'vampir', 'True')
                emoji = '🧛‍♂️'
                if Settings.sex == 'она':
                    emoji = '🧛‍♀️'
                text = f'{emoji} Вампиризм добавлен'
            Settings.refresh(f_config)
            temp = await msg.reply(text, quote = False)
            if msgtl == '.вампиризм':
                temp1 = await app.send_sticker(msg.chat.id, 'media/vampir_with_wine.webp')
                asyncio.create_task(func.delete_msg([msg, temp, temp1], 16))
            else:
                asyncio.create_task(func.delete_msg([msg, temp], 16))
        
        if msgtl == '.ао-' and msg.reply_to_message and msg.reply_to_message.from_user and msg.reply_to_message.from_user.id == Me.me.id \
        or msgtl == '!ао-':
            chat = msg.chat.id
            title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
            chat_tag = f'<a href="tg://openmessage?user_id={chat}">{title}</a>'
            if str(chat) in Settings.autoanswer_chats and 'auto_infecter_chat' in Settings.autoanswer_chats[str(chat)] and Settings.autoanswer_chats[str(chat)]['auto_infecter_chat'] == 'True':
                aic_val = 'False'
                func.chats_config_append({str(chat): {'chat_title': title, 'auto_infecter_chat': aic_val}}, f_chats_config)
                text = f'❌📜 <b>{chat_tag}</b> вынесен из списка'
            
                temp = await msg.reply(text, quote = False)
                
                func.chats_config_append({str(chat): {'chat_title': title, 'auto_infecter_chat': aic_val}}, f_chats_config)
                Settings.refresh(f_config)
                asyncio.create_task(func.delete_msg([msg, temp], 4))
        
        if msgtl == '.ао+' and msg.reply_to_message and msg.reply_to_message.from_user and msg.reply_to_message.from_user.id == Me.me.id \
        or msgtl == '!ао+':
            chat = msg.chat.id
            title = (msg.chat.title if msg.chat.title else msg.chat.first_name)
            chat_tag = f'<a href="tg://openmessage?user_id={chat}">{title}</a>'
            if str(chat) in Settings.autoanswer_chats and 'auto_infecter_chat' in Settings.autoanswer_chats[str(chat)] and Settings.autoanswer_chats[str(chat)]['auto_infecter_chat'] == 'True':
                return
            else:
                aic_val = 'True'
                text = f'📜 <b>{chat_tag}</b> внесен в список'
                
                temp = await msg.reply(text, quote = False)
                
                func.chats_config_append({str(chat): {'chat_title': title, 'auto_infecter_chat': aic_val}}, f_chats_config)
                Settings.refresh(f_config)
                asyncio.create_task(func.delete_msg([msg, temp], 4))
        
        if re.fullmatch(r'\.аот (\d+-\d+|\d+)с', msgtl) and msg.reply_to_message and msg.reply_to_message.from_user and msg.reply_to_message.from_user.id == Me.me.id \
        or re.fullmatch(r'!аот (\d+-\d+|\d+)с', msgtl):
            time = msgt.split(' ')[1].replace('с', '')
            temp = await msg.reply(
                f'⏳ Делей заражений, изменен <b>{Settings.auto_infecter_time}с</b> <i>></i> <b>{time}с</b>',
                quote = False
            )
            func.edit_cf(f_config, 'user_settings', 'auto_infecter_time', time)
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 8))



