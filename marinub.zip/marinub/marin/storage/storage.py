from config import MeInfo, MyIllnesses, Zapominalka, JsRead, CycleTimers, Settings, \
    f_config, VictimsEclusionRead

Settings = Settings(f_config)
me_inf = MeInfo()
my_illnesses = MyIllnesses()
VictimsEclusionRead = VictimsEclusionRead()
JsRead = JsRead()
ctimer = CycleTimers()
cycle_timers = {}
